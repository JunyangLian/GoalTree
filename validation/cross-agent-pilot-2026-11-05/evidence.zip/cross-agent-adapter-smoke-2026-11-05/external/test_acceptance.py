import unittest
from code import value
class Acceptance(unittest.TestCase):
    def test_value(self):
        self.assertEqual(value, 2)
