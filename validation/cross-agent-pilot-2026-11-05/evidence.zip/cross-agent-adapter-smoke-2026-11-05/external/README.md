Offline adapter fixture. Not a formal benchmark task.
