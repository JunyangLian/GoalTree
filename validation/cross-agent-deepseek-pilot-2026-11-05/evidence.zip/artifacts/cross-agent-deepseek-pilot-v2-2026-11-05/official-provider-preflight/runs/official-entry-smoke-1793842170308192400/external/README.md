Non-benchmark official-provider adapter smoke fixture. Fix add in code.py; do not modify tests.
