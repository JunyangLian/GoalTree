import re
from datetime import datetime

_NONDIGIT_RE = re.compile(r'\D')

def isoparse(iso_str):
    """Parses the limited subset of `ISO8601-formatted time`_ strings as
    returned by :meth:`datetime.datetime.isoformat`.

    >>> epoch_dt = datetime.fromtimestamp(0, timezone.utc).replace(tzinfo=None)
    >>> iso_str = epoch_dt.isoformat()
    >>> print(iso_str)
    1970-01-01T00:00:00
    >>> isoparse(iso_str)
    datetime.datetime(1970, 1, 1, 0, 0)

    >>> utcnow = datetime.now(timezone.utc).replace(tzinfo=None)
    >>> utcnow == isoparse(utcnow.isoformat())
    True

    For further datetime parsing, see the `iso8601`_ package for strict
    ISO parsing and `dateutil`_ package for loose parsing and more.

    .. _ISO8601-formatted time: https://en.wikipedia.org/wiki/ISO_8601
    .. _iso8601: https://pypi.python.org/pypi/iso8601
    .. _dateutil: https://pypi.python.org/pypi/python-dateutil

    """
    parts = _NONDIGIT_RE.split(iso_str)

    # The first six components are date/time fields; the optional seventh is
    # the fractional second, which is a fraction of a second (not an integer
    # count of microseconds), so it must be right-padded to 6 digits and
    # truncated beyond microsecond precision.
    dt_args = [int(p) for p in parts[:6]]
    fraction = parts[6] if len(parts) > 6 else ''
    microsecond = int((fraction + '000000')[:6]) if fraction else 0

    return datetime(*dt_args, microsecond=microsecond)
