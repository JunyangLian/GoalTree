import re
from datetime import datetime

_ISO_RE = re.compile(
    r'^(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})'
    r'(?:[T ](?P<hour>\d{2}):(?P<minute>\d{2}):(?P<second>\d{2})'
    r'(?:\.(?P<fraction>\d+))?)?$'
)

def isoparse(iso_str):
    """Parses the limited subset of `ISO8601-formatted time`_ strings as
    returned by :meth:`datetime.datetime.isoformat`.

    >>> epoch_dt = datetime.fromtimestamp(0, timezone.utc).replace(tzinfo=None)
    >>> iso_str = epoch_dt.isoformat()
    >>> print(iso_str)
    1970-01-01T00:00:00
    >>> isoparse(iso_str)
    datetime.datetime(1970, 1, 1, 0, 0)

    >>> utcnow = datetime.now(timezone.utc).replace(tzinfo=None)
    >>> utcnow == isoparse(utcnow.isoformat())
    True

    For further datetime parsing, see the `iso8601`_ package for strict
    ISO parsing and `dateutil`_ package for loose parsing and more.

    .. _ISO8601-formatted time: https://en.wikipedia.org/wiki/ISO_8601
    .. _iso8601: https://pypi.python.org/pypi/iso8601
    .. _dateutil: https://pypi.python.org/pypi/python-dateutil

    """
    match = _ISO_RE.match(iso_str)
    if match is None:
        raise ValueError("Invalid isoformat string: %r" % (iso_str,))

    parts = match.groupdict()
    dt_args = [int(parts[name]) for name in ('year', 'month', 'day')]

    if parts['hour'] is not None:
        dt_args.extend(
            int(parts[name]) for name in ('hour', 'minute', 'second')
        )

        fraction = parts['fraction']
        if fraction is not None:
            # Scale the fractional seconds to microseconds: pad to 6 digits,
            # truncating anything beyond microsecond precision.
            dt_args.append(int((fraction + '000000')[:6]))

    return datetime(*dt_args)
