import re
from datetime import datetime

_NONDIGIT_RE = re.compile(r'\D')
_FRACTION_RE = re.compile(r'\.(\d+)')

def isoparse(iso_str):
    """Parses the limited subset of `ISO8601-formatted time`_ strings as
    returned by :meth:`datetime.datetime.isoformat`.

    >>> epoch_dt = datetime.fromtimestamp(0, timezone.utc).replace(tzinfo=None)
    >>> iso_str = epoch_dt.isoformat()
    >>> print(iso_str)
    1970-01-01T00:00:00
    >>> isoparse(iso_str)
    datetime.datetime(1970, 1, 1, 0, 0)

    >>> utcnow = datetime.now(timezone.utc).replace(tzinfo=None)
    >>> utcnow == isoparse(utcnow.isoformat())
    True

    For further datetime parsing, see the `iso8601`_ package for strict
    ISO parsing and `dateutil`_ package for loose parsing and more.

    .. _ISO8601-formatted time: https://en.wikipedia.org/wiki/ISO_8601
    .. _iso8601: https://pypi.python.org/pypi/iso8601
    .. _dateutil: https://pypi.python.org/pypi/python-dateutil

    """
    microsecond = None
    fraction_match = _FRACTION_RE.search(iso_str)
    if fraction_match:
        # Fractional seconds are right-padded / truncated to 6 digits so that
        # e.g. ".851" -> 851000 and ".123456789" -> 123456 microseconds.
        digits = (fraction_match.group(1) + '000000')[:6]
        microsecond = int(digits)
        iso_str = iso_str[:fraction_match.start()] + iso_str[fraction_match.end():]

    dt_args = [int(p) for p in _NONDIGIT_RE.split(iso_str)]
    if microsecond is not None:
        if len(dt_args) > 6:
            dt_args.insert(6, microsecond)
        else:
            dt_args.append(microsecond)
    return datetime(*dt_args)
